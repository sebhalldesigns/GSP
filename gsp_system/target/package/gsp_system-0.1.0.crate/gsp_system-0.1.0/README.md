# gsp_system - OpenGSP System Library

**gsp_system** is a thin and lightweight platform abstraction layer providing core system functionality such as application lifecycle, window creation and events.
