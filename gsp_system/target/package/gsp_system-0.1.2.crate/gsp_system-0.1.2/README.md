# gsp_system - OpenGSP System Library

**gsp_system** is a thin and lightweight platform abstraction layer providing core system functionality such as application lifecycle, window creation and events.

## PLEASE NOTE

gsp_system is at a very early stage in development and is very much a work in progress, with extremely minimal functionality.
It is currently suitable for creating a window and receiving and intercepting resize and close events on windows only.