# gsp_gpi - OpenGSP Graphics Programming Interface Library

**gsp_gpi** is a platform-agnostic API for 3D and 2D graphics. It aims to provide complete and comprehensive support for all modern platforms from a single codebase.
