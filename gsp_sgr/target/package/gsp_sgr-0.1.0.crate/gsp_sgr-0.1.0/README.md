# gsp_sgr - OpenGSP Software Graphics Renderer Library

**gsp_sgr** is a platform-agnostic software renderer, aiming to provide full support of the OpenGSP GPI library on any system, including those without graphics such as embedded microcontrollers.
